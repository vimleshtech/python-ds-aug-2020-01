#!/usr/bin/env python
# coding: utf-8

# In[1]:


#import pandas 
import pandas as pd 

df = pd.DataFrame() #create dataframe (is table : combination of row and column)
print(df)


# In[3]:


#create dataframe or table from dict 
d ={'eid':[1,2,3,4,5,6,7,8,9],
   'name':['Raman Sinha','Deepali','Jyoti Gulati','Nitisha Srivastava','Mohit Agarwal','Ritesh','Raman Siha','Gaurav','Kshitiz'],
   'age':[23,31,34,21,23,25,45,28,29]}

print(d) #print dict
#create dataframe from dict
df = pd.DataFrame(data=d)
print(df)


# In[7]:


#get list of columns
print(df.columns)

#get list of index
print(df.index)

#rename column
df.columns = ['Employe Code','Employee Name','Age']
print(df)

#Series: list of column  is known as series

print(df['Age'])


# In[8]:


print(df[['Age','Employee Name']]) #show selected columns 


# In[13]:


#Uni-variate Analysis 
#get data shape
print(df.shape) #8 rows and 3 cols

print(df.info())
print(df.isnull())

print(df.isnull().sum()) #get null count for every column
print(df.isnull().count()) #get values count for every column


# In[17]:


#####shop top 5 rows
print(df.head())

print(df.head(3)) #get 3 rows

#print from buttom 
print(df.tail()) #default 5 rows

print(df.tail(n=2))


# In[18]:


df.describe()
'''
count 
mean/avg
std (sqt of var )
min / lowest
1st Qtr value 
mid / 50% 
3rd qtr 
max/highet
'''


# In[22]:


##data distribuation 
print(df.groupby('Age').size())
print(df.groupby('Age').count())
print(df.groupby('Age').mean())
print(df.groupby('Age').min())
print(df.groupby('Age').max())


# In[25]:


###order by: sort data in asc or desc order
print(df.sort_values('Age',ascending=True))

print(df.sort_values('Age',ascending=False))

print(df.sort_values('Employee Name',ascending=False))


# In[26]:


#filter rows 
df[df['Age']>21]


# In[27]:


df[df['Age']<=21]


# In[30]:


#import file or data 
#pip install pandas
#pip install xlrd 

data = pd.read_excel(r'C:\Users\Vimlesh.Kumar\Downloads\Sample - Superstore.xls',sheet_name='Orders')

print(data.shape)



# In[31]:


print(data.head())

